<?php

declare(strict_types=1);

use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;
use Slim\App;
use Slim\Interfaces\RouteCollectorProxyInterface as Group;

return function (App $app) {
  $app->options('/{routes:.*}', function (Request $request, Response $response) {
    // CORS Pre-Flight OPTIONS Request Handler
    return $response;
  });

  $app->get('/', function (Request $request, Response $response) {
    $response->getBody()->write("API ROOT");
    return $response;
  });

  $app->get('/problems', function (Request $request, Response $response) {
    $servername = "localhost";
    $username = "root";
    $password = "";
    $database = "psubh";

    // Create connection
    $conn = new mysqli($servername, $username, $password, $database);

    // Check connection
    if ($conn->connect_error) {
      return $response;
    }

    $result = $conn->query("SELECT problem_code FROM problems");

    $resp = array();
    while ($row = $result->fetch_row()) {
      array_push($resp, $row[0]);
    }

    $response->getBody()->write(json_encode($resp));
    return $response;
  });


  $app->get('/tags', function (Request $request, Response $response) {
    session_start();
    $servername = "localhost";
    $username = "root";
    $password = "";
    $database = "psubh";

    // Create connection
    $conn = new mysqli($servername, $username, $password, $database);

    // Check connection
    if ($conn->connect_error) {
      return $response;
    }

    if (isset($_SESSION['user_id'])) {
      $user_id = $_SESSION['user_id'];
      $stmt = $conn->prepare('SELECT user_tag_name FROM user_tags where user_tag_user_id = ? union SELECT tag_name From tags');
      $stmt->bind_param("i", $user_id);
      $stmt->execute();
      $result = $stmt->get_result();
    } else {
      $result = $conn->query("SELECT tag_name FROM tags");
    }

    $resp = array();
    while ($row = $result->fetch_row()) {
      array_push($resp, $row[0]);
    }

    $response->getBody()->write(json_encode($resp));
    return $response;
  });

  $app->get('/tag/{tag_name}', function (Request $request, Response $response, $args) {
    session_start();
    $servername = "localhost";
    $username = "root";
    $password = "";
    $database = "psubh";

    // Create connection
    $conn = new mysqli($servername, $username, $password, $database);

    // Check connection
    if ($conn->connect_error) {
      return $response;
    }

    $name = $args['tag_name'];

    if (isset($_SESSION['user_id'])) {
      $user_id = $_SESSION['user_id'];
      $stmt = $conn->prepare('select * from (SELECT * From tags UNION SELECT user_tag_id, user_tag_name, user_tag_count, "user_tag" FROM user_tags where user_tag_user_id=?) as ut where ut.tag_name=?');
      $stmt->bind_param("is", $user_id, $name);
    } else {
      $stmt = $conn->prepare("SELECT * FROM tags where tag_name=?");
      $stmt->bind_param("s", $name);
    }

    $stmt->execute();
    $result = $stmt->get_result();

    if ($resp = $result->fetch_assoc()) {
      $response->getBody()->write(json_encode($resp));
    }

    return $response;
  });

  $app->post('/problem', function (Request $request, Response $response, $args) {
    session_start();
    $parsed_body = $request->getParsedBody();
    $data = json_decode($parsed_body['tags']);
    if (count($data) < 1) {
      return $response;
    }
    $servername = "localhost";
    $username = "root";
    $password = "";
    $database = "psubh";

    // Create connection
    $conn = new mysqli($servername, $username, $password, $database);

    // Check connection
    if ($conn->connect_error) {
      return $response;
    }

    if (!isset($_SESSION['user_id'])) {
      $stmt = $conn->prepare("select problem_code, (Select GROUP_CONCAT(tags.tag_name SEPARATOR ', ') from  problem_tag join tags on problem_tag.tag_id = tags.tag_id where problem_id = p.problem_id) as problem_tags, problem_solved, problem_attempted, problem_author from problem_tag as pt join tags as t on pt.tag_id = t.tag_id join problems as p on pt.problem_id = p.problem_id where t.tag_name in (?" . str_repeat(",?", count($data) - 1) . ") GROUP BY p.problem_id HAVING COUNT(p.problem_id)=" . count($data));
      $stmt->bind_param(str_repeat("s", count($data)), ...$data);
    } else {
      $user_id = $_SESSION['user_id'];
      $stmt = $conn->prepare("SELECT problem_code, (select GROUP_CONCAT(t_pt.tag_name SEPARATOR ', ') from (SELECT problem_user_tag.problem_id, user_tags.user_tag_name as tag_name from problem_user_tag join user_tags on problem_user_tag.user_tag_id = user_tags.user_tag_id where user_tags.user_tag_user_id=? UNION select problem_tag.problem_id, tags.tag_name from problem_tag join tags on problem_tag.tag_id = tags.tag_id) as t_pt where t_pt.problem_id = p.problem_id) as problem_tags, problem_solved, problem_attempted, problem_author from (SELECT problem_user_tag.problem_id, user_tags.user_tag_name as tag_name from problem_user_tag join user_tags on problem_user_tag.user_tag_id = user_tags.user_tag_id where user_tags.user_tag_user_id=? UNION select problem_tag.problem_id, tags.tag_name from problem_tag join tags on problem_tag.tag_id = tags.tag_id) as pt join problems as p on p.problem_id = pt.problem_id where pt.tag_name in (?" . str_repeat(",?", count($data) - 1) . ") GROUP BY p.problem_id HAVING COUNT(p.problem_id)=" . count($data));
      $stmt->bind_param("ii" . str_repeat("s", count($data)), $user_id, $user_id, ...$data);
    }

    $stmt->execute();
    $result = $stmt->get_result();
    $resp = array();
    while ($row = $result->fetch_row()) {
      array_push($resp, $row);
    }
    $response->getBody()->write(json_encode($resp));
    return $response;
  });

  $app->post('/login', function (Request $request, Response $response, $args) {
    session_start();
    $parsed_body = $request->getParsedBody();
    $u_name = $parsed_body['u_name'];
    $u_pass = $parsed_body['u_pass'];
    $servername = "localhost";
    $username = "root";
    $password = "";
    $database = "psubh";

    // Create connection
    $conn = new mysqli($servername, $username, $password, $database);

    // Check connection
    if ($conn->connect_error) {
      return $response;
    }
    $stmt = $conn->prepare("select user_id, user_name from users where user_name = ? and user_password = ?");
    $stmt->bind_param("ss", $u_name, $u_pass);
    $stmt->execute();
    $result = $stmt->get_result();
    $resp = array("result" => "failed");
    if ($row = $result->fetch_row()) {
      $_SESSION['user_id'] = $row[0];
      $_SESSION['user_name'] = $row[1];
      $resp = array("result" => "success");
    }
    $response->getBody()->write(json_encode($resp));
    return $response;
  });

  $app->post('/register', function (Request $request, Response $response, $args) {
    session_start();
    $parsed_body = $request->getParsedBody();
    $u_name = $parsed_body['u_name'];
    $u_pass = $parsed_body['u_pass'];
    $servername = "localhost";
    $username = "root";
    $password = "";
    $database = "psubh";

    // Create connection
    $conn = new mysqli($servername, $username, $password, $database);

    // Check connection
    if ($conn->connect_error) {
      return $response;
    }
    $stmt = $conn->prepare("select user_id from users where user_name = ?");
    $stmt->bind_param("s", $u_name);
    $stmt->execute();
    $result = $stmt->get_result();
    $resp = array("result" => "failed");
    if ($row = $result->fetch_row()) { }
    else {
      $stmt = $conn->prepare("INSERT INTO users(user_name, user_password) VALUES(?, ?)");
      $stmt->bind_param("ss", $u_name, $u_pass);
      $stmt->execute();
      $resp = array("result" => "success");
    }
    $response->getBody()->write(json_encode($resp));
    return $response;
  });

  $app->get('/username', function (Request $request, Response $response) {
    session_start();
    if (isset($_SESSION['user_name'])) {
      $resp = array("username" => $_SESSION['user_name'], "logged_in" => true);
      
    } else {
      $resp = array("logged_in" => false);
    }
    $response->getBody()->write(json_encode($resp));
    return $response;
  });

  $app->get('/usertags', function (Request $request, Response $response) {
    session_start();
    $servername = "localhost";
    $username = "root";
    $password = "";
    $database = "psubh";

    // Create connection
    $conn = new mysqli($servername, $username, $password, $database);

    // Check connection
    if ($conn->connect_error) {
      return $response;
    }

    if (isset($_SESSION['user_id'])) {
      $user_id = $_SESSION['user_id'];
      $stmt = $conn->prepare('SELECT user_tag_name FROM user_tags where user_tag_user_id = ?');
      $stmt->bind_param("i", $user_id);
      $stmt->execute();
      $result = $stmt->get_result();
      $resp = array();
      while ($row = $result->fetch_row()) {
        array_push($resp, $row[0]);
      }
      $response->getBody()->write(json_encode($resp));
    }    
    return $response;
  });

  $app->post('/createtag', function (Request $request, Response $response) {
    session_start();
    $servername = "localhost";
    $username = "root";
    $password = "";
    $database = "psubh";

    // Create connection
    $conn = new mysqli($servername, $username, $password, $database);

    // Check connection
    if ($conn->connect_error) {
      return $response;
    }
    if (!isset($_SESSION['user_id'])) {
      $resp = array("result" => "Not Logged in");
    } else {
      $user_id = $_SESSION['user_id'];
      $parsed_body = $request->getParsedBody();
      
      if ((!isset($parsed_body['tag'])) || ($parsed_body['tag'] == "")) {
        $resp = array("result" => "Invalid Tag Name");
        $response->getBody()->write(json_encode($resp));
        return $response;
      }
      $tag = $parsed_body['tag'];
      $stmt = $conn->prepare("select ut.tag_name from (SELECT user_tag_name as tag_name FROM user_tags where user_tag_user_id = ? union SELECT tags.tag_name From tags) as ut where ut.tag_name=?");
      $stmt->bind_param("is", $user_id, $tag);
      $stmt->execute();
      $result = $stmt->get_result();
      if ($row = $result->fetch_row()) {
        $resp = array("result" => "Tag Exists");
      } else {
        $stmt = $conn->prepare("INSERT INTO user_tags(user_tag_name, user_tag_user_id) VALUES(?, ?)");
        $stmt->bind_param("si", $tag, $user_id);
        $stmt->execute();
        $resp = array("result" => "Tag Created");
      }
    }
    $response->getBody()->write(json_encode($resp));
    return $response;
  });

  $app->post('/linktag', function (Request $request, Response $response) {
    session_start();
    $servername = "localhost";
    $username = "root";
    $password = "";
    $database = "psubh";

    // Create connection
    $conn = new mysqli($servername, $username, $password, $database);

    // Check connection
    if ($conn->connect_error) {
      return $response;
    }
    if (!isset($_SESSION['user_id'])) {
      $resp = array("result" => "Not Logged in");
    } else {
      $user_id = $_SESSION['user_id'];
      $parsed_body = $request->getParsedBody();

      if ((!isset($parsed_body['tag'])) || ($parsed_body['tag'] == "")) {
        $resp = array("result" => "Invalid Tag Name");
        $response->getBody()->write(json_encode($resp));
        return $response;
      }

      $tag = $parsed_body['tag'];

      if ((!isset($parsed_body['problem'])) || ($parsed_body['problem'] == "")) {
        $resp = array("result" => "Invalid Problem Name");
        $response->getBody()->write(json_encode($resp));
        return $response;
      }

      $prob = $parsed_body['problem'];
      
      $stmt = $conn->prepare("select user_tag_id from user_tags where user_tag_user_id = ? and user_tag_name = ?");
      $stmt->bind_param("is", $user_id, $tag);
      $stmt->execute();
      $result = $stmt->get_result();
      if ($row = $result->fetch_row()) {
        $tag_id = $row[0];
      } else {
        $resp = array("result" => "Tag Does Not Exists");
        $response->getBody()->write(json_encode($resp));
        return $response;
      }

      $stmt = $conn->prepare("select problem_id from problems where problem_code = ?");
      $stmt->bind_param("s", $prob);
      $stmt->execute();
      $result = $stmt->get_result();
      if ($row = $result->fetch_row()) {
        $prob_id = $row[0];
      } else {
        $resp = array("result" => "Problem Does Not Exists");
        $response->getBody()->write(json_encode($resp));
        return $response;
      }

      $stmt = $conn->prepare("INSERT INTO `problem_user_tag`(`problem_id`, `user_tag_id`) VALUES(?, ?)");
      $stmt->bind_param("ii", $prob_id, $tag_id);
      if ($stmt->execute()) {
        $stmt = $conn->prepare("UPDATE user_tags SET user_tag_count = user_tag_count + 1 where user_tag_id = ?");
        $stmt->bind_param("i", $tag_id);
        $stmt->execute();
        $resp = array("result" => "Tag Attached to Problem");
      } else {
        $resp = array("result" => "Link Already Exists");
      }
    }
    $response->getBody()->write(json_encode($resp));
    return $response;
  });
};
